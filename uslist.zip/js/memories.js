(() => {

    "use strict";


    // =========================================================
    // STORAGE
    // =========================================================

    const STORAGE_KEY = "uslist_memories";


    // =========================================================
    // ELEMENTS
    // =========================================================

    const memoriesGrid =
        document.getElementById("memoriesGrid");

    const memoryEmptyState =
        document.getElementById("memoryEmptyState");

    const memoryCount =
        document.getElementById("memoryCount");

    const memoryModal =
        document.getElementById("memoryModal");

    const openMemoryModal =
        document.getElementById("openMemoryModal");

    const emptyMemoryButton =
        document.getElementById("emptyMemoryButton");

    const closeMemoryModal =
        document.getElementById("closeMemoryModal");

    const cancelMemory =
        document.getElementById("cancelMemory");

    const memoryForm =
        document.getElementById("memoryForm");

    const filterButtons =
        document.querySelectorAll(
            ".memory-toolbar .filter-button"
        );


    // Delete modal

    const deleteMemoryModal =
        document.getElementById("deleteMemoryModal");

    const deleteMemoryText =
        document.getElementById("deleteMemoryText");

    const cancelMemoryDelete =
        document.getElementById("cancelMemoryDelete");

    const confirmMemoryDelete =
        document.getElementById("confirmMemoryDelete");


    // Mobile sidebar

    const menuButton =
        document.getElementById("menuButton");

    const sidebar =
        document.getElementById("sidebar");

    const sidebarClose =
        document.getElementById("sidebarClose");


    // =========================================================
    // STATE
    // =========================================================

    let currentFilter = "all";

    let memoryToDelete = null;


    // =========================================================
    // STORAGE
    // =========================================================

    function getMemories() {

        try {

            const saved =
                localStorage.getItem(STORAGE_KEY);

            if (!saved) {
                return [];
            }

            const memories =
                JSON.parse(saved);

            return Array.isArray(memories)
                ? memories
                : [];

        } catch (error) {

            console.error(
                "UsList: Could not load memories.",
                error
            );

            return [];

        }

    }


    function saveMemories(memories) {

        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(memories)
        );

    }


    // =========================================================
    // ADD MEMORY MODAL
    // =========================================================

    function openModal() {

        if (!memoryModal) return;

        memoryModal.classList.add("show");


        const titleInput =
            document.getElementById("memoryTitle");


        if (titleInput) {

            setTimeout(() => {
                titleInput.focus();
            }, 100);

        }

    }


    function closeModal() {

        if (!memoryModal) return;

        memoryModal.classList.remove("show");


        if (memoryForm) {
            memoryForm.reset();
        }


        const romance =
            document.querySelector(
                'input[name="memoryCategory"][value="romance"]'
            );


        if (romance) {
            romance.checked = true;
        }

    }


    if (openMemoryModal) {

        openMemoryModal.addEventListener(
            "click",
            openModal
        );

    }


    if (emptyMemoryButton) {

        emptyMemoryButton.addEventListener(
            "click",
            openModal
        );

    }


    if (closeMemoryModal) {

        closeMemoryModal.addEventListener(
            "click",
            closeModal
        );

    }


    if (cancelMemory) {

        cancelMemory.addEventListener(
            "click",
            closeModal
        );

    }


    if (memoryModal) {

        memoryModal.addEventListener(
            "click",
            event => {

                if (
                    event.target === memoryModal
                ) {

                    closeModal();

                }

            }
        );

    }


    // =========================================================
    // ADD MEMORY
    // =========================================================

    if (memoryForm) {

        memoryForm.addEventListener(
            "submit",
            event => {

                event.preventDefault();


                const title =
                    document
                        .getElementById("memoryTitle")
                        ?.value
                        .trim();


                const date =
                    document
                        .getElementById("memoryDate")
                        ?.value;


                const description =
                    document
                        .getElementById("memoryDescription")
                        ?.value
                        .trim();


                const selectedCategory =
                    document.querySelector(
                        'input[name="memoryCategory"]:checked'
                    );


                const category =
                    selectedCategory
                        ? selectedCategory.value
                        : "romance";


                if (!title || !date) {
                    return;
                }


                const memory = {

                    id: crypto.randomUUID(),

                    title,

                    date,

                    description,

                    category,

                    createdAt:
                        new Date().toISOString()

                };


                const memories =
                    getMemories();


                memories.unshift(memory);


                saveMemories(memories);


                closeModal();

                renderMemories();

            }
        );

    }


    // =========================================================
    // FILTERS
    // =========================================================

    filterButtons.forEach(button => {

        button.addEventListener(
            "click",
            () => {

                const filter =
                    button.dataset.filter;


                if (!filter) {
                    return;
                }


                currentFilter =
                    filter;


                // Update active tab

                filterButtons.forEach(
                    filterButton => {

                        filterButton.classList.remove(
                            "active"
                        );

                    }
                );


                button.classList.add("active");


                // Update displayed memories

                renderMemories();

            }
        );

    });


    // =========================================================
    // RENDER
    // =========================================================

    function renderMemories() {

        if (!memoriesGrid) {
            return;
        }


        const memories =
            getMemories();


        let filteredMemories;


        if (currentFilter === "all") {

            filteredMemories =
                memories;

        } else {

            filteredMemories =
                memories.filter(memory => {

                    return (
                        memory.category ===
                        currentFilter
                    );

                });

        }


        // Clear grid

        memoriesGrid.innerHTML = "";


        // Update count

        if (memoryCount) {

            memoryCount.textContent =
                `${filteredMemories.length} ${
                    filteredMemories.length === 1
                        ? "memory"
                        : "memories"
                }`;

        }


        // Nothing found

        if (
            filteredMemories.length === 0
        ) {

            showEmptyState();

            return;

        }


        hideEmptyState();


        // Render memories

        filteredMemories.forEach(
            memory => {

                memoriesGrid.appendChild(
                    createMemoryCard(memory)
                );

            }
        );

    }


    // =========================================================
    // EMPTY STATE
    // =========================================================

    function showEmptyState() {

        if (!memoryEmptyState) {
            return;
        }


        const title =
            memoryEmptyState.querySelector("h3");


        const text =
            memoryEmptyState.querySelector("p");


        if (currentFilter === "all") {

            if (title) {
                title.textContent =
                    "No memories yet";
            }


            if (text) {
                text.textContent =
                    "Start saving the moments that make your relationship special.";
            }

        } else {

            const category =
                formatCategory(currentFilter);


            if (title) {

                title.textContent =
                    `No ${category.toLowerCase()} memories`;

            }


            if (text) {

                text.textContent =
                    `Memories you add to ${category.toLowerCase()} will appear here.`;

            }

        }


        memoryEmptyState.classList.add(
            "visible"
        );

    }


    function hideEmptyState() {

        if (!memoryEmptyState) {
            return;
        }


        memoryEmptyState.classList.remove(
            "visible"
        );

    }


    // =========================================================
    // CREATE MEMORY CARD
    // =========================================================

    function createMemoryCard(memory) {

        const article =
            document.createElement("article");


        article.className =
            "memory-card";


        article.innerHTML = `

            <div class="memory-cover">

                <div class="memory-cover-icon">

                    <i class="bx bx-heart"></i>

                </div>

            </div>


            <div class="memory-content">

                <div class="memory-top">

                    <span class="memory-category">
                        ${formatCategory(memory.category)}
                    </span>


                    <button
                        type="button"
                        class="memory-delete"
                        data-action="delete"
                        data-id="${memory.id}"
                        aria-label="Delete memory"
                    >

                        <i class="bx bx-trash"></i>

                    </button>

                </div>


                <h3>
                    ${escapeHTML(memory.title)}
                </h3>


                <span class="memory-date">

                    <i class="bx bx-calendar"></i>

                    ${formatDate(memory.date)}

                </span>


                ${
                    memory.description
                        ? `
                            <p>
                                ${escapeHTML(
                                    memory.description
                                )}
                            </p>
                        `
                        : ""
                }

            </div>

        `;


        return article;

    }


    // =========================================================
    // CARD ACTIONS
    // =========================================================

    if (memoriesGrid) {

        memoriesGrid.addEventListener(
            "click",
            event => {

                const button =
                    event.target.closest(
                        "[data-action]"
                    );


                if (!button) {
                    return;
                }


                if (
                    button.dataset.action ===
                    "delete"
                ) {

                    deleteMemory(
                        button.dataset.id
                    );

                }

            }
        );

    }


    // =========================================================
    // DELETE
    // =========================================================

    function deleteMemory(id) {

        const memories =
            getMemories();


        const memory =
            memories.find(
                item => item.id === id
            );


        if (!memory) {
            return;
        }


        memoryToDelete =
            id;


        if (deleteMemoryText) {

            deleteMemoryText.textContent =
                `"${memory.title}" will be permanently removed.`;

        }


        if (deleteMemoryModal) {

            deleteMemoryModal.classList.add(
                "show"
            );

        }

    }


    function closeDeleteModal() {

        if (deleteMemoryModal) {

            deleteMemoryModal.classList.remove(
                "show"
            );

        }


        memoryToDelete = null;

    }


    if (cancelMemoryDelete) {

        cancelMemoryDelete.addEventListener(
            "click",
            closeDeleteModal
        );

    }


    if (confirmMemoryDelete) {

        confirmMemoryDelete.addEventListener(
            "click",
            () => {

                if (!memoryToDelete) {
                    return;
                }


                const memories =
                    getMemories();


                const updated =
                    memories.filter(
                        memory =>
                            memory.id !==
                            memoryToDelete
                    );


                saveMemories(updated);


                closeDeleteModal();

                renderMemories();

            }
        );

    }


    if (deleteMemoryModal) {

        deleteMemoryModal.addEventListener(
            "click",
            event => {

                if (
                    event.target ===
                    deleteMemoryModal
                ) {

                    closeDeleteModal();

                }

            }
        );

    }


    // =========================================================
    // HELPERS
    // =========================================================

    function formatCategory(category) {

        const categories = {

            romance: "Romance",

            travel: "Travel",

            dates: "Dates",

            milestones: "Milestones"

        };


        return (
            categories[category] ||
            "Memory"
        );

    }


    function formatDate(dateString) {

        if (!dateString) {
            return "";
        }


        const date =
            new Date(
                `${dateString}T00:00:00`
            );


        if (
            Number.isNaN(
                date.getTime()
            )
        ) {

            return dateString;

        }


        return date.toLocaleDateString(
            undefined,
            {
                day: "numeric",
                month: "long",
                year: "numeric"
            }
        );

    }


    function escapeHTML(value) {

        const div =
            document.createElement("div");


        div.textContent =
            value;


        return div.innerHTML;

    }


    // =========================================================
    // ESCAPE KEY
    // =========================================================

    document.addEventListener(
        "keydown",
        event => {

            if (event.key !== "Escape") {
                return;
            }


            if (
                memoryModal &&
                memoryModal.classList.contains("show")
            ) {

                closeModal();

            }


            if (
                deleteMemoryModal &&
                deleteMemoryModal.classList.contains("show")
            ) {

                closeDeleteModal();

            }

        }
    );


    // =========================================================
    // MOBILE SIDEBAR
    // =========================================================

    if (menuButton && sidebar) {

        menuButton.addEventListener(
            "click",
            () => {

                sidebar.classList.add(
                    "open"
                );

            }
        );

    }


    if (sidebarClose && sidebar) {

        sidebarClose.addEventListener(
            "click",
            () => {

                sidebar.classList.remove(
                    "open"
                );

            }
        );

    }


    document.addEventListener(
        "click",
        event => {

            if (
                window.innerWidth <= 850 &&
                sidebar &&
                sidebar.classList.contains("open") &&
                menuButton &&
                !sidebar.contains(event.target) &&
                !menuButton.contains(event.target)
            ) {

                sidebar.classList.remove(
                    "open"
                );

            }

        }
    );


    // =========================================================
    // INITIALIZE
    // =========================================================

    renderMemories();


})();