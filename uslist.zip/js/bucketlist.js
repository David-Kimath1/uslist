const STORAGE_KEY = "uslist_bucket_items";


// ==================== ELEMENTS ====================

const bucketList = document.getElementById("bucketList");
const emptyState = document.getElementById("emptyState");
const itemCount = document.getElementById("itemCount");

const addModal = document.getElementById("addModal");

const openAddModal = document.getElementById("openAddModal");
const emptyAddButton = document.getElementById("emptyAddButton");

const closeAddModal = document.getElementById("closeAddModal");
const cancelAdd = document.getElementById("cancelAdd");

const addItemForm = document.getElementById("addItemForm");

const filterButtons =
    document.querySelectorAll(".filter-button");


// ==================== STATE ====================

let currentFilter = "all";


// ==================== STORAGE ====================

function getItems() {

    return JSON.parse(
        localStorage.getItem(STORAGE_KEY)
    ) || [];

}


function saveItems(items) {

    localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(items)
    );

}


// ==================== MODAL ====================

function openModal() {

    addModal.classList.add("show");

    setTimeout(() => {

        document
            .getElementById("itemTitle")
            .focus();

    }, 100);

}


function closeModal() {

    addModal.classList.remove("show");

    addItemForm.reset();

}


openAddModal.addEventListener(
    "click",
    openModal
);


emptyAddButton.addEventListener(
    "click",
    openModal
);


closeAddModal.addEventListener(
    "click",
    closeModal
);


cancelAdd.addEventListener(
    "click",
    closeModal
);


addModal.addEventListener(
    "click",
    event => {

        if (event.target === addModal) {
            closeModal();
        }

    }
);


// ==================== ADD ITEM ====================

addItemForm.addEventListener(
    "submit",
    event => {

        event.preventDefault();


        const title =
            document
                .getElementById("itemTitle")
                .value
                .trim();


        const description =
            document
                .getElementById("itemDescription")
                .value
                .trim();


        const category =
            document.querySelector(
                'input[name="category"]:checked'
            ).value;


        if (!title) return;


        const newItem = {

            id: crypto.randomUUID(),

            title,

            description,

            category,

            completed: false,

            createdAt: new Date().toISOString(),

            completedAt: null

        };


        const items = getItems();

        items.push(newItem);

        saveItems(items);


        closeModal();

        renderItems();

    }
);


// ==================== COMPLETE ITEM ====================

function toggleItem(id) {

    const items = getItems();


    const updatedItems = items.map(item => {

        if (item.id !== id) {
            return item;
        }


        const completed = !item.completed;


        return {

            ...item,

            completed,

            completedAt: completed
                ? new Date().toISOString()
                : null

        };

    });


    saveItems(updatedItems);

    renderItems();

}


// ==================== DELETE ITEM ====================


// ==================== DELETE ITEM ====================

const deleteModal =
    document.getElementById("deleteModal");

const deleteText =
    document.getElementById("deleteText");

const cancelDelete =
    document.getElementById("cancelDelete");

const confirmDelete =
    document.getElementById("confirmDelete");

let itemToDelete = null;


function deleteItem(id) {

    const items = getItems();

    const item =
        items.find(item => item.id === id);

    if (!item) return;

    itemToDelete = id;

    deleteText.textContent =
        `"${item.title}" will be permanently removed.`;

    deleteModal.classList.add("show");
}


function closeDeleteModal() {

    deleteModal.classList.remove("show");

    itemToDelete = null;
}


cancelDelete.addEventListener(
    "click",
    closeDeleteModal
);


confirmDelete.addEventListener(
    "click",
    () => {

        if (!itemToDelete) return;

        const items = getItems();

        const updatedItems =
            items.filter(
                item => item.id !== itemToDelete
            );

        saveItems(updatedItems);

        closeDeleteModal();

        renderItems();

    }
);


deleteModal.addEventListener(
    "click",
    event => {

        if (event.target === deleteModal) {
            closeDeleteModal();
        }

    }
);


document.addEventListener(
    "keydown",
    event => {

        if (
            event.key === "Escape" &&
            deleteModal.classList.contains("show")
        ) {

            closeDeleteModal();

        }

    }
);


// ==================== FILTER ====================

filterButtons.forEach(button => {

    button.addEventListener(
        "click",
        () => {

            filterButtons.forEach(btn =>
                btn.classList.remove("active")
            );


            button.classList.add("active");


            currentFilter =
                button.dataset.filter;


            renderItems();

        }
    );

});


// ==================== RENDER ====================

function renderItems() {

    const items = getItems();


    let filteredItems = items;


    if (currentFilter === "active") {

        filteredItems =
            items.filter(
                item => !item.completed
            );

    }


    if (currentFilter === "completed") {

        filteredItems =
            items.filter(
                item => item.completed
            );

    }


    bucketList.innerHTML = "";


    itemCount.textContent =
        `${filteredItems.length} ${
            filteredItems.length === 1
                ? "item"
                : "items"
        }`;


    if (filteredItems.length === 0) {

        emptyState.classList.add("visible");

        return;

    }


    emptyState.classList.remove("visible");


    filteredItems.forEach(item => {

        bucketList.appendChild(
            createItemElement(item)
        );

    });

}


// ==================== CREATE ITEM ====================

function createItemElement(item) {

    const article =
        document.createElement("article");


    article.className =
        `bucket-item ${
            item.completed
                ? "completed"
                : ""
        }`;


    article.innerHTML = `

        <button
            class="item-checkbox"
            aria-label="Mark item as complete"
            data-action="toggle"
            data-id="${item.id}"
        >

            <i class="bx bx-check"></i>

        </button>


        <div class="item-main">

            <div class="item-top">

                <span class="item-category">
                    ${item.category}
                </span>

            </div>


            <h3>
                ${escapeHTML(item.title)}
            </h3>


            ${
                item.description
                    ? `
                        <p>
                            ${escapeHTML(item.description)}
                        </p>
                    `
                    : ""
            }


            <span class="item-date">

                <i class="bx bx-calendar"></i>

                Added ${formatDate(item.createdAt)}

            </span>

        </div>


        <button
            class="item-delete"
            aria-label="Delete item"
            data-action="delete"
            data-id="${item.id}"
        >

            <i class="bx bx-trash"></i>

        </button>

    `;


    return article;

}


// ==================== EVENTS ====================

bucketList.addEventListener(
    "click",
    event => {

        const button =
            event.target.closest("button");


        if (!button) return;


        const action =
            button.dataset.action;


        const id =
            button.dataset.id;


        if (action === "toggle") {
            toggleItem(id);
        }


        if (action === "delete") {
            deleteItem(id);
        }

    }
);


// ==================== HELPERS ====================

function formatDate(dateString) {

    const date =
        new Date(dateString);


    return date.toLocaleDateString(
        undefined,
        {
            day: "numeric",
            month: "short",
            year: "numeric"
        }
    );

}


function escapeHTML(value) {

    const div =
        document.createElement("div");


    div.textContent = value;


    return div.innerHTML;

}


// ==================== MOBILE SIDEBAR ====================

const menuButton =
    document.getElementById("menuButton");

const sidebar =
    document.getElementById("sidebar");

const sidebarClose =
    document.getElementById("sidebarClose");


menuButton.addEventListener(
    "click",
    () => {
        sidebar.classList.add("open");
    }
);


sidebarClose.addEventListener(
    "click",
    () => {
        sidebar.classList.remove("open");
    }
);


document.addEventListener(
    "click",
    event => {

        if (
            window.innerWidth <= 850 &&
            sidebar.classList.contains("open") &&
            !sidebar.contains(event.target) &&
            !menuButton.contains(event.target)
        ) {

            sidebar.classList.remove("open");

        }

    }
);


// ==================== INITIALIZE ====================

renderItems();